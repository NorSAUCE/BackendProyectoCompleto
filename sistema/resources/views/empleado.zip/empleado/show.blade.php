<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Detalles del Empleado</h1>

    <p><strong>Nombre:</strong> {{ $empleado->Nombre }}</p>
    <p><strong>Apellido:</strong> {{ $empleado->Apellido }}</p>
    <p><strong>Correo:</strong> {{ $empleado->Correo }}</p>

    <a href="{{ route('empleado.index') }}">Volver a la lista</a>
</body>
</html>