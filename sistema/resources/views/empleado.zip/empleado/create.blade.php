<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Formulario de creacion de empleado</h1>
    <form action="{{route('empleado.store')}}" method="POST" enctype="multipart/form-data">
    @csrf    
    <label for="Nombre">Nombre: </label>
        <input type="text" name="Nombre" id="Nombre">
        <br>
        <label for="Apellido">Apellido: </label>
        <input type="text" name="Apellido" id="Apellido">
        <br>
        <label for="Correo">Correo: </label>
        <input type="email" name="Correo" id="Correo">
        <br>
        <label for="Foto">Foto</label>
        <input type="file" name="Foto" id="Foto">

        <input type="submit" value="Enviar">
    </form>
</body>
</html>